﻿namespace Ejercicio06CentroEscolar
{
    partial class fProfesores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnMostrarDatosProf = new System.Windows.Forms.Button();
            this.btnOrdenarProfAlfabeticamente = new System.Windows.Forms.Button();
            this.btnMostrarListaProf = new System.Windows.Forms.Button();
            this.btnEliminarProfesor = new System.Windows.Forms.Button();
            this.bntAgregarProfesor = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnMostrarProfImparteAsig = new System.Windows.Forms.Button();
            this.btnEliminarAsigProf = new System.Windows.Forms.Button();
            this.btnAñadirAsigProfesor = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnMostrarDatosProf);
            this.groupBox1.Controls.Add(this.btnOrdenarProfAlfabeticamente);
            this.groupBox1.Controls.Add(this.btnMostrarListaProf);
            this.groupBox1.Controls.Add(this.btnEliminarProfesor);
            this.groupBox1.Controls.Add(this.bntAgregarProfesor);
            this.groupBox1.Location = new System.Drawing.Point(57, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(687, 169);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Profesores";
            // 
            // btnMostrarDatosProf
            // 
            this.btnMostrarDatosProf.Location = new System.Drawing.Point(406, 107);
            this.btnMostrarDatosProf.Name = "btnMostrarDatosProf";
            this.btnMostrarDatosProf.Size = new System.Drawing.Size(225, 29);
            this.btnMostrarDatosProf.TabIndex = 4;
            this.btnMostrarDatosProf.Text = "Mostrar Datos Profesores";
            this.btnMostrarDatosProf.UseVisualStyleBackColor = true;
            this.btnMostrarDatosProf.Click += new System.EventHandler(this.btnMostrarDatosProf_Click);
            // 
            // btnOrdenarProfAlfabeticamente
            // 
            this.btnOrdenarProfAlfabeticamente.BackColor = System.Drawing.Color.Transparent;
            this.btnOrdenarProfAlfabeticamente.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOrdenarProfAlfabeticamente.Location = new System.Drawing.Point(52, 107);
            this.btnOrdenarProfAlfabeticamente.Name = "btnOrdenarProfAlfabeticamente";
            this.btnOrdenarProfAlfabeticamente.Size = new System.Drawing.Size(308, 29);
            this.btnOrdenarProfAlfabeticamente.TabIndex = 3;
            this.btnOrdenarProfAlfabeticamente.Text = "Ordenar Profesores por Orden Alfabético";
            this.btnOrdenarProfAlfabeticamente.UseVisualStyleBackColor = false;
            this.btnOrdenarProfAlfabeticamente.Click += new System.EventHandler(this.btnOrdenarProfAlfabeticamente_Click);
            // 
            // btnMostrarListaProf
            // 
            this.btnMostrarListaProf.Location = new System.Drawing.Point(474, 40);
            this.btnMostrarListaProf.Name = "btnMostrarListaProf";
            this.btnMostrarListaProf.Size = new System.Drawing.Size(157, 29);
            this.btnMostrarListaProf.TabIndex = 2;
            this.btnMostrarListaProf.Text = "Mostrar Lista Profesores";
            this.btnMostrarListaProf.UseVisualStyleBackColor = true;
            this.btnMostrarListaProf.Click += new System.EventHandler(this.btnMostrarListaProf_Click);
            // 
            // btnEliminarProfesor
            // 
            this.btnEliminarProfesor.Location = new System.Drawing.Point(262, 40);
            this.btnEliminarProfesor.Name = "btnEliminarProfesor";
            this.btnEliminarProfesor.Size = new System.Drawing.Size(157, 29);
            this.btnEliminarProfesor.TabIndex = 1;
            this.btnEliminarProfesor.Text = "Eliminar Profesor";
            this.btnEliminarProfesor.UseVisualStyleBackColor = true;
            this.btnEliminarProfesor.Click += new System.EventHandler(this.btnEliminarProfesor_Click);
            // 
            // bntAgregarProfesor
            // 
            this.bntAgregarProfesor.Location = new System.Drawing.Point(52, 40);
            this.bntAgregarProfesor.Name = "bntAgregarProfesor";
            this.bntAgregarProfesor.Size = new System.Drawing.Size(157, 29);
            this.bntAgregarProfesor.TabIndex = 0;
            this.bntAgregarProfesor.Text = "Introducir Profesor";
            this.bntAgregarProfesor.UseVisualStyleBackColor = true;
            this.bntAgregarProfesor.Click += new System.EventHandler(this.bntAgregarProfesor_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnMostrarProfImparteAsig);
            this.groupBox2.Controls.Add(this.btnEliminarAsigProf);
            this.groupBox2.Controls.Add(this.btnAñadirAsigProfesor);
            this.groupBox2.Location = new System.Drawing.Point(57, 243);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(687, 155);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Asignaturas";
            // 
            // btnMostrarProfImparteAsig
            // 
            this.btnMostrarProfImparteAsig.Location = new System.Drawing.Point(211, 77);
            this.btnMostrarProfImparteAsig.Name = "btnMostrarProfImparteAsig";
            this.btnMostrarProfImparteAsig.Size = new System.Drawing.Size(242, 44);
            this.btnMostrarProfImparteAsig.TabIndex = 7;
            this.btnMostrarProfImparteAsig.Text = "Mostrar profesores que imparten una asignatura";
            this.btnMostrarProfImparteAsig.UseVisualStyleBackColor = true;
            this.btnMostrarProfImparteAsig.Click += new System.EventHandler(this.btnMostrarProfImparteAsig_Click);
            // 
            // btnEliminarAsigProf
            // 
            this.btnEliminarAsigProf.Location = new System.Drawing.Point(380, 32);
            this.btnEliminarAsigProf.Name = "btnEliminarAsigProf";
            this.btnEliminarAsigProf.Size = new System.Drawing.Size(204, 29);
            this.btnEliminarAsigProf.TabIndex = 6;
            this.btnEliminarAsigProf.Text = "Eliminar Asignatura de un Profesor";
            this.btnEliminarAsigProf.UseVisualStyleBackColor = true;
            this.btnEliminarAsigProf.Click += new System.EventHandler(this.btnEliminarAsigProf_Click);
            // 
            // btnAñadirAsigProfesor
            // 
            this.btnAñadirAsigProfesor.Location = new System.Drawing.Point(79, 32);
            this.btnAñadirAsigProfesor.Name = "btnAñadirAsigProfesor";
            this.btnAñadirAsigProfesor.Size = new System.Drawing.Size(204, 29);
            this.btnAñadirAsigProfesor.TabIndex = 5;
            this.btnAñadirAsigProfesor.Text = "Añadir Asignatura a Profesor";
            this.btnAñadirAsigProfesor.UseVisualStyleBackColor = true;
            this.btnAñadirAsigProfesor.Click += new System.EventHandler(this.btnAñadirAsigProfesor_Click);
            // 
            // fProfesores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "fProfesores";
            this.Text = "fProfesores";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnMostrarDatosProf;
        private System.Windows.Forms.Button btnOrdenarProfAlfabeticamente;
        private System.Windows.Forms.Button btnMostrarListaProf;
        private System.Windows.Forms.Button btnEliminarProfesor;
        private System.Windows.Forms.Button bntAgregarProfesor;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnMostrarProfImparteAsig;
        private System.Windows.Forms.Button btnEliminarAsigProf;
        private System.Windows.Forms.Button btnAñadirAsigProfesor;
    }
}